package Employee_Demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class fetchEmployee {

	public static void main(String[] args) throws SQLException {
		Connection connection = null;

		try {
			connection = Connect_Database.getConnection();

			Employee Employee = new Employee();
			Employee.setEmployeeId(100);

			String query = "select * from Employee where EmployeeId = '"+Employee.getEmployeeId()+"'";

			Statement stmt = connection.createStatement();

			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String designation = rs.getString(3);
				int salary = rs.getInt(4);
				String address = rs.getString(5);

				Employee emp = new Employee(id, name, designation, salary, address);
				System.out.println(emp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}
	}
}
