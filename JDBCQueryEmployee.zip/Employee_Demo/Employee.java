package Employee_Demo;

public class Employee {
	
	private int EmployeeId;
	private String EmployeeName;
	private String EmployeeDesignation;
	private int EmployeeSalary;
	private String EmployeeAddress;
	
	public Employee() {
		super();
	}

	public Employee(int EmployeeId, String EmployeeName, String EmployeeDesignation, int EmployeeSalary,
			String EmployeeAddress) {
		super();
		this.EmployeeId = EmployeeId;
		this.EmployeeName = EmployeeName;
		this.EmployeeDesignation = EmployeeDesignation;
		this.EmployeeSalary = EmployeeSalary;
		this.EmployeeAddress = EmployeeAddress;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(int EmployeeId) {
		this.EmployeeId = EmployeeId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String EmployeeName) {
		this.EmployeeName = EmployeeName;
	}

	public String getEmployeeDesignation() {
		return EmployeeDesignation;
	}

	public void setEmployeeDesignation(String EmployeeDesignation) {
		this.EmployeeDesignation = EmployeeDesignation;
	}

	public int getEmployeeSalary() {
		return EmployeeSalary;
	}

	public void setEmployeeSalary(int EmployeeSalary) {
		this.EmployeeSalary = EmployeeSalary;
	}

	public String getEmployeeAddress() {
		return EmployeeAddress;
	}

	public void setEmployeeAddress(String EmployeeAddress) {
		this.EmployeeAddress = EmployeeAddress;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", EmployeeDesignation="
				+ EmployeeDesignation + ", EmployeeSalary=" + EmployeeSalary + ", EmployeeAddress=" + EmployeeAddress
				+ "]";
	}
	
	
	

}
