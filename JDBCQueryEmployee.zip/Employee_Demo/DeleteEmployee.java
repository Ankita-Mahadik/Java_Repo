package Employee_Demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteEmployee {

	public static void main(String[] args) throws SQLException {

		Connection connection = null;

		try {
			connection = Connect_Database.getConnection();
			Employee emp = new Employee();
			emp.setEmployeeName("yash");

			String query = "DELETE FROM Employee WHERE EmployeeName = ?";

			PreparedStatement stmt = connection.prepareStatement(query);

			stmt.setString(1, emp.getEmployeeName());

			int status = stmt.executeUpdate();

			if (status > 0) {
				System.out.println("Student data deleted from database table.");
			} else {
				System.out.println("Student data not deleted from database table.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}

	}

}
