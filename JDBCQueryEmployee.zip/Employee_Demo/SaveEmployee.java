package Employee_Demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import mysql.Database_Connection;

public class SaveEmployee {

	public static void main(String[] args) throws SQLException {
		Connection connection = null;
		try {
			connection = Connect_Database.getConnection();

			Employee emp = new Employee();
			emp.setEmployeeId(18);
			emp.setEmployeeName("Deepa");
			emp.setEmployeeDesignation("Sales HR");
			emp.setEmployeeSalary(7000);
			emp.setEmployeeAddress("Pune");

			String query = "insert into Employee values(?,?,?,?,?)";

			// get the PreparedStatement Object
			PreparedStatement stmt = connection.prepareStatement(query);

			stmt.setInt(1, emp.getEmployeeId());
			stmt.setString(2, emp.getEmployeeName());
			stmt.setString(3, emp.getEmployeeDesignation());
			stmt.setInt(4, emp.getEmployeeSalary());
			stmt.setString(5,	emp.getEmployeeAddress());

			int status = stmt.executeUpdate();
			if (status > 0) {
				System.out.println("Data get inserted in Database Table.");
			} else {
				System.out.println("Data don't get inserted in Database Table.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
			
		}
	}
}
