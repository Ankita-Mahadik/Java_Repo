package Employee_Demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class CommitRollback {

	public static void main(String[] args)throws SQLException {
		Connection connection = null;
		Scanner sc = null;

		try {
			connection = Connect_Database.getConnection();
			
			while(true) {
				//disable the autoCommit of MySQL server.
				connection.setAutoCommit(false);
				
				sc = new Scanner(System.in);
				
				System.out.println("Enter Employee id");
				int id = sc.nextInt();
				
				System.out.println("Enter Employee name");
				String name = sc.next();
				
				System.out.println("Enter Employee Designation");
				String designation = sc.next();
				
				System.out.println("Enter Employee salary");
				int salary = sc.nextInt();
				
				System.out.println("Enter Employee address");
				String address = sc.next();
				
				//Employee Object
				Employee Employee = new Employee(id,name,designation,salary,address);
				
				String query = "insert into Employee values(?,?,?,?,?)";
				
				PreparedStatement stmt = connection.prepareStatement(query);
				
				stmt.setInt(1, Employee.getEmployeeId());
				stmt.setString(2, Employee.getEmployeeName());
				stmt.setString(3, Employee.getEmployeeDesignation());
				stmt.setInt(4, Employee.getEmployeeSalary());
				stmt.setString(5, Employee.getEmployeeAddress());
				
				stmt.executeUpdate();
				
				System.out.println("\nwant to 'commit/rollback' the customer object?");
				String inputAns = sc.next().toLowerCase();
				
				if(inputAns.equals("commit"))
				{
					connection.commit();
				}
				else if(inputAns.equals("rollback"))
				{
					connection.rollback();
				}
				
				System.out.println("\nwant to save more customer objects? 'yes/no'");
				String response = sc.next().toLowerCase();

				if(response.equals("no"))
				{
					break;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		finally 
		{
			connection.close();	
			sc.close();
		}
		}
	}
