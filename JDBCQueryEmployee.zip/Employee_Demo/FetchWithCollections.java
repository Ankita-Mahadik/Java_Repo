package Employee_Demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FetchWithCollections {
	
	public static void main(String[] args) throws SQLException {
		Connection connection = null;

		try {
			connection = Connect_Database.getConnection();

			Employee emp = new Employee();

			String query = "select * from Employee";
			
			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery(query);
			
			List<Employee> listOfEmployees = new ArrayList<Employee>();
			
			while(rs.next()) 
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String designation = rs.getString(3);
				int salary = rs.getInt(4);
				String address = rs.getString(5);
				
				//String sContact = rs.getString(5);

				//long contact = Long.parseLong(sContact);  Using parse to convert from string to long
				
				Employee Employee = new Employee(id,name,designation,salary,address);
				listOfEmployees.add(Employee);
			}
			
			for(Employee Employee: listOfEmployees)
			{
				if(Employee.getEmployeeAddress().equalsIgnoreCase("pune"))
				{
					System.out.println(Employee);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}
	}


}
