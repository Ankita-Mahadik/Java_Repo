package Employee_Demo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;



public class UpdateEmployee{

	public static void main(String[] args) throws SQLException {

		Connection connection = null;

		try {

			connection = Connect_Database.getConnection();
			Employee emp = new Employee();
			emp.setEmployeeName("Jay");
			emp.setEmployeeDesignation("HR");
			emp.setEmployeeSalary(7000);
			emp.setEmployeeAddress("Kolkata");
			
			emp.setEmployeeId(10);

			String query = "update Employee set EmployeeName = '"+emp.getEmployeeName()+"', EmployeeDesignation = '"+emp.getEmployeeDesignation()+"', EmployeeSalary = '"+emp.getEmployeeSalary()+"', EmployeeAddress = '"+emp.getEmployeeAddress()+"' where EmployeeId = '"+emp.getEmployeeId()+"'";

			Statement statement = connection.createStatement();

			int status = statement.executeUpdate(query);
			if (status > 0) {
				System.out.println("Student data updated in database table.");
			} else {
				System.out.println("Student data not updated in database table.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}

	}

}
