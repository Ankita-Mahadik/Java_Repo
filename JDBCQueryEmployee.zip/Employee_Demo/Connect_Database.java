package Employee_Demo;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect_Database {

	public static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DATABASE_URL = "jdbc:mysql://localhost:3306/Employeedb";
	public static final String DATABASE_USERNAME = "root";
	public static final String DATABASE_PASSWORD = "root";

	public static Connection getConnection() 
	{
		Connection connection = null;
		
		try 
		{
			Class.forName(DATABASE_DRIVER);
			connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return connection;
	}
}
